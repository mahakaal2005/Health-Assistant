import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun Group73(modifier: Modifier = Modifier) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(40.dp, Alignment.Start),
        modifier = modifier
        ) {
        Box(
            modifier = Modifier
                        .requiredWidth(width = 375.dp)
                        .requiredHeight(height = 143.dp)
            ) {
            Box(
                modifier = Modifier
                                .align(alignment = Alignment.TopStart)
                                .offset(x = 152.5.dp,
                                                y = 16.5.dp)
                                .requiredSize(size = 70.dp)
                ) {
                Image(
                    painter = painterResource(id = R.drawable.background),
                    contentDescription = "Background",
                    modifier = Modifier
                                        .align(alignment = Alignment.BottomCenter)
                                        .offset(x = 0.dp,
                                                            y = 0.dp)
                                        .requiredSize(size = 70.dp)
                                        .clip(shape = RoundedCornerShape(40.dp)))
                Image(
                    painter = painterResource(id = R.drawable.bxplussvg),
                    contentDescription = "bx-plus.svg",
                    colorFilter = ColorFilter.tint(Color.White),
                    modifier = Modifier
                                        .align(alignment = Alignment.BottomCenter)
                                        .offset(x = 0.5.dp,
                                                            y = (-4.5).dp)
                                        .requiredSize(size = 60.dp))
                }
            Image(
                painter = painterResource(id = R.drawable.rectangle1),
                contentDescription = "Rectangle 1",
                modifier = Modifier
                                .align(alignment = Alignment.BottomCenter)
                                .offset(x = 0.dp,
                                                y = 0.dp)
                                .requiredWidth(width = 375.dp)
                                .requiredHeight(height = 80.dp)
                                .clip(shape = RoundedCornerShape(10.dp))
                                .shadow(elevation = AppShadows.effect_Shadow_3,
                                                shape = RoundedCornerShape(10.dp)))
            Row(
                modifier = Modifier
                                .align(alignment = Alignment.BottomCenter)
                                .offset(x = 0.dp,
                                                y = (-25).dp)
                ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.Start),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                                        .requiredWidth(width = 71.dp)
                    ) {
                    Icon(
                        painter = painterResource(id = R.drawable.boldtrueactivetruestyledefault),
                        contentDescription = "Home",
                        tint = AppColors.color_Main_Color)
                    }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.Start),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                                        .requiredWidth(width = 71.dp)
                    ) {
                    Icon(
                        painter = painterResource(id = R.drawable.boldfalseactivefalsestyledefault),
                        contentDescription = "Search",
                        tint = AppColors.color_Secondary_Color)
                    }
                Spacer(
                    modifier = Modifier
                                        .requiredWidth(width = 71.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.Start),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                                        .requiredWidth(width = 71.dp)
                    ) {
                    Icon(
                        painter = painterResource(id = R.drawable.boldfalseactivefalsestyledefault),
                        contentDescription = "Bell",
                        tint = AppColors.color_Secondary_Color,
                        modifier = Modifier
                                                .clip(shape = RoundedCornerShape(5.dp)))
                    }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.Start),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                                        .requiredWidth(width = 71.dp)
                    ) {
                    Icon(
                        painter = painterResource(id = R.drawable.boldfalseactivefalsestyledefault),
                        contentDescription = "Setting",
                        tint = AppColors.color_Secondary_Color,
                        modifier = Modifier
                                                .clip(shape = RoundedCornerShape(5.dp)))
                    }
                }
            }
        }
 }

@Preview
@Composable
private fun Group73Preview() {
    Group73(Modifier)
 }