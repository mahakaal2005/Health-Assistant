import androidx.compose.ui.graphics.Color

object AppColors {
    val color_Secondary_Color = Color(0XFFABB7C2)
    val color_Secondary_Color_2 = Color(0XFFCFD6DC)
    val color_Black_Color = Color(0XFF0D0B26)
}