import androidx.compose.ui.unit.dp

object AppShadows {
    val effect_box_shadow = 12.dp
}